<template>
    <div>右侧内容</div>
    
</template>
<script>
export default{

}
</script>

<style>

</style>