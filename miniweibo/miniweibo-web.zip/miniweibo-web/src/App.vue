<template>
  <div id="app">
      默认页面
      <router-link to="layout">layout</router-link>
      <router-view></router-view>
  </div>
</template>

<script>
import router from './router';



export default {
  name: "app",
  components: { router }
}
</script>


